from gi.repository import Gtk, GLib
from .license import BREEZY_GNOME_FEATURES
from .licensedialog import LicenseDialog
from .runtimeenvironment import RuntimeEnvironment
from .statemanager import StateManager
from .settingsmanager import SettingsManager
from .connecteddevice import ConnectedDevice
from .failedverification import FailedVerification
from .nodevice import NoDevice
from .nodriver import NoDriver
from .noextension import NoExtension
from .nolicense import NoLicense

@Gtk.Template(resource_path='/com/xronlinux/BreezyDesktop/gtk/window.ui')
class BreezydesktopWindow(Gtk.ApplicationWindow):
    __gtype_name__ = 'BreezydesktopWindow'

    main_content = Gtk.Template.Child()
    license_action_needed_banner = Gtk.Template.Child()
    license_action_needed_button = Gtk.Template.Child()
    missing_breezy_features_banner = Gtk.Template.Child()
    missing_breezy_features_button = Gtk.Template.Child()
    pose_position_needs_pro_banner = Gtk.Template.Child()
    pose_position_needs_pro_button = Gtk.Template.Child()
    update_available_banner = Gtk.Template.Child()

    def __init__(self, version, skip_verification, **kwargs):
        super().__init__(**kwargs)

        self.runtime = RuntimeEnvironment.get_instance()
        self.connected_device = ConnectedDevice()
        self.failed_verification = FailedVerification()
        self.no_device = NoDevice()
        self.no_driver = NoDriver()
        self.no_extension = NoExtension()
        self.no_license = NoLicense()
        
        self._skip_verification = skip_verification

        self.settings = SettingsManager.get_instance().settings
        self.state_manager = StateManager.get_instance()
        self.state_manager.connect('device-update', self._handle_state_update)
        self.state_manager.connect('notify::license-action-needed', self._handle_state_update)
        self.state_manager.connect('notify::license-present', self._handle_state_update)
        self.state_manager.connect('notify::enabled-features-list', self._handle_state_update)
        self.state_manager.connect('notify::connected-device-pose-has-position', self._handle_state_update)
        self.settings.connect('changed::debug-no-device', self._handle_settings_update)

        self.license_action_needed_button.connect('clicked', self._on_license_button_clicked)
        self.missing_breezy_features_button.connect('clicked', self._on_license_button_clicked)
        self.pose_position_needs_pro_button.connect('clicked', self._on_license_button_clicked)

        self._handle_state_update(self.state_manager, None)

        self._skip_verification = skip_verification

        self.connect("destroy", self._on_window_destroy)

        self.runtime.check_for_update(version, self._on_update_check_result)

    def _handle_settings_update(self, settings_manager, key):
        self._handle_state_update(self.state_manager, None)

    def _handle_state_update(self, state_manager, val):
        GLib.idle_add(self._handle_state_update_gui, state_manager)

    def _handle_state_update_gui(self, state_manager):
        enabled_features_list = state_manager.get_property('enabled-features-list') or []
        enabled_breezy_features = [feature for feature in enabled_features_list if feature in BREEZY_GNOME_FEATURES]
        breezy_features_granted = len(enabled_breezy_features) > 0
        self.missing_breezy_features_banner.set_revealed(not breezy_features_granted)
        self.license_action_needed_banner.set_revealed(state_manager.get_property('license-action-needed') == True)

        pose_has_position = state_manager.get_property('connected-device-pose-has-position') == True
        pro_enabled = 'productivity_pro' in enabled_features_list
        self.pose_position_needs_pro_banner.set_revealed(state_manager.connected_device_name and pose_has_position and breezy_features_granted and not pro_enabled)

        for child in self.main_content:
            self.main_content.remove(child)

        if self.settings.get_boolean('debug-no-device'):
            self.main_content.append(self.connected_device)
            self.connected_device.set_device_name('Fake device')
        elif not self._skip_verification and not self.runtime.verify():
            self.main_content.append(self.failed_verification)
        elif not self.runtime.is_installed():
            self.main_content.append(self.no_extension)
        elif not self.state_manager.driver_running:
            self.main_content.append(self.no_driver)
        elif not self.state_manager.license_present:
            self.main_content.append(self.no_license)
        elif not state_manager.connected_device_name and self.runtime.shows_no_device_view:
            self.main_content.append(self.no_device)
        else:
            self.main_content.append(self.connected_device)
            self.connected_device.set_device_name(state_manager.connected_device_name or self.runtime.no_device_label())
        
        self.set_resizable(True)
        self.set_default_size(1, 1)
        
        return False

    def _on_license_button_clicked(self, widget):
        dialog = LicenseDialog()
        dialog.set_transient_for(widget.get_ancestor(Gtk.Window))
        dialog.present()

    def _on_update_check_result(self, latest_version):
        GLib.idle_add(self.update_available_banner.set_revealed, latest_version is not None)

    def _on_window_destroy(self, widget):
        self.state_manager.disconnect_by_func(self._handle_state_update)